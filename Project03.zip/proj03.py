
#Use the following strings in your prompts and print statements
"\nError. Please try again"
"Enter a file name: "
"\n\nGross Domestic Product"

#Use these contansts when displaying the results
HEADER_FORMAT = "{:<10s}{:>8s}{:>6s}{:>18s}"
DATA_FORMAT = "{:<10s}{:>8.1f}{:>6d}{:>18.2f}"

def open_file():
    ''' Docstring'''   

    pass # replace this line with your code
    
def find_min_percent(line):
    ''' Docstring'''  

    pass # replace this line with your code

def find_max_percent(line):
    ''' Docstring'''   

    pass # replace this line with your code

def find_gdp(line, index):
    ''' Docstring'''   
    
    pass # replace this line with your code

        
def display(min_val, min_year, min_val_gdp, max_val, max_year, max_val_gdp):
    ''' Docstring'''   
    
    pass # replace this line with your code

def main():
    
    pass # replace this line with your code

# These two lines allow this program to be imported into other code
# such as our function tests code allowing other functions to be run
# and tested without 'main' running.  However, when this program is
# run alone, 'main' will execute.
#DO NOT CHANGE THESE 2 lines  
if __name__ == "__main__":
    main()
